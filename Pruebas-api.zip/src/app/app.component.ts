import { Component, OnInit } from '@angular/core';
import { JsonPlaceholderService } from './jsonplaceholder.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'pruebas-api';
  posts: any[] = [];
  post: any;
  comments: any[] = [];
  selectedPost: any;

  constructor(private jsonPlaceholderService: JsonPlaceholderService) { }

  ngOnInit() {
    this.fetchPosts();
    this.fetchSinglePost();
    this.fetchComments();
  }

  fetchPosts() {
    this.jsonPlaceholderService.getPosts().subscribe(data => {
      console.log('posts obtenidos', data);
      this.posts = data;
    }, error => {
      console.error('Error al recuperar posts', error);
    });
  }

  fetchSinglePost() {
    this.jsonPlaceholderService.getPost(1).subscribe(data => {
      console.log('post obtenido:', data);
      this.post = data;
    }, error => {
      console.error('Error para obtener un solo post:', error);
    });
  }

  fetchComments() {
    this.jsonPlaceholderService.getComments().subscribe(data => {
      console.log('Comentarios obtenidos:', data);
      this.comments = data;
    }, error => {
      console.error('Error al obtener comentarios', error);
    });
  }

  selectPost(post: any) {
    this.selectedPost = post;
    this.fetchCommentsByPostId(post.id);
  }

  fetchCommentsByPostId(postId: number) {
    this.jsonPlaceholderService.getCommentsByPostId(postId).subscribe(data => {
      console.log('comentarios obtenidos por id', postId, ':', data);
      this.comments = data;
    }, error => {
      console.error('Error al recuperar comentarios pior el id:', error);
    });
  }
}
